#include "header_math.h"
#include "calc.h"

int add_values (int a, int b) {
    return (a+b);
}