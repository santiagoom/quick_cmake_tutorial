#ifndef CMAKE_TESTAPP_CALC_H
#define CMAKE_TESTAPP_CALC_H

int add_values (int a, int b);

#endif //CMAKE_TESTAPP_CALC_H
